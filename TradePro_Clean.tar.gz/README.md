# Futures Trading Bot

A professional Flask-based cryptocurrency trading bot with advanced technical analysis, real-time market data, and automated Telegram alerts.

## Features

- **Advanced Technical Analysis**: Multi-indicator signal generation using RSI, MACD, Bollinger Bands
- **Real-time Market Data**: Live price feeds from multiple cryptocurrency exchanges
- **Automated Telegram Alerts**: Position monitoring, profit targets, and stop-loss notifications
- **Professional Dashboard**: Modern UI with real-time charts and trading signals
- **Risk Management**: Automated stop-loss and position sizing calculations
- **Portfolio Tracking**: Comprehensive trade history and performance analytics

## Technology Stack

- **Backend**: Flask, SQLAlchemy, PostgreSQL
- **Frontend**: Bootstrap 5, Chart.js, Socket.IO
- **APIs**: Coinbase Pro, Binance, CoinGecko
- **Notifications**: Telegram Bot API
- **Deployment**: Gunicorn WSGI server

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/futures-trading-bot.git
cd futures-trading-bot
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
```bash
# Database
DATABASE_URL=postgresql://username:password@localhost/tradingbot

# Telegram Bot
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here

# Flask
SESSION_SECRET=your_secret_key_here
```

4. Initialize the database:
```bash
flask db upgrade
```

5. Run the application:
```bash
gunicorn --bind 0.0.0.0:5000 main:app
```

## Configuration

### Telegram Setup

1. Create a new bot with @BotFather on Telegram
2. Get your bot token and add it to environment variables
3. Find your chat ID and add it to environment variables
4. Visit `/telegram-setup` to test the connection

### Trading Parameters

The bot uses conservative leverage and risk management by default:
- Maximum leverage: 10x for high-confidence signals
- Position sizing: Based on account balance and risk tolerance
- Stop-loss: Automatically calculated based on volatility

## Usage

### Dashboard

Access the main dashboard at `/` to view:
- Real-time trading signals
- Portfolio performance
- Market analysis
- Active positions

### API Endpoints

- `GET /api/signals` - Get current trading signals
- `GET /api/portfolio` - Get portfolio metrics
- `POST /api/start-monitoring` - Start position monitoring
- `POST /api/test-telegram` - Test Telegram connection

### Telegram Commands

The bot automatically sends alerts for:
- New high-confidence trading opportunities (90%+)
- Profit target achievements (50% and 100%)
- Stop-loss warnings and triggers
- Portfolio performance updates

## File Structure

```
├── main.py              # Application entry point
├── app.py               # Flask app configuration
├── models.py            # Database models
├── routes.py            # API routes and endpoints
├── fast_signals.py      # Signal generation engine
├── telegram_notifier.py # Telegram integration
├── position_monitor.py  # Position monitoring system
├── backup_data_provider.py # Market data sources
├── templates/           # HTML templates
├── static/             # CSS, JS, images
└── requirements.txt    # Python dependencies
```

## Security

- Never commit API keys or secrets to the repository
- Use environment variables for all sensitive configuration
- Enable two-factor authentication for your GitHub account
- Regularly rotate API keys and tokens

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-feature`)
3. Commit your changes (`git commit -am 'Add new feature'`)
4. Push to the branch (`git push origin feature/new-feature`)
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Disclaimer

This trading bot is for educational and research purposes only. Cryptocurrency trading involves substantial risk of loss. Always conduct your own research and never invest more than you can afford to lose.

## Support

For support and questions, please open an issue on GitHub or contact the development team.