from app import app
from auto_monitor import start_auto_monitoring
import threading

# Start auto-monitoring system
threading.Thread(target=start_auto_monitoring, daemon=True).start()
from routes import *
from routes_dynamic import dynamic_bp

# Register blueprints and routes
app.register_blueprint(dynamic_bp)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
